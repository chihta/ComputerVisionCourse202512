# My First Project > 2025-12-17 1:48pm
https://universe.roboflow.com/jan-dt26j/my-first-project-yzxvq

Provided by a Roboflow user
License: CC BY 4.0

